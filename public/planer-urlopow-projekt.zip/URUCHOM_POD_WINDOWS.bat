@echo off
title Plan urlopu - Uruchamianie
echo ====================================================
echo   PLAN URLOPU (React 19 + TypeScript + Vite)
echo ====================================================
echo.
echo Sprawdzanie srodowiska Node.js...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [BLAD] Node.js nie jest zainstalowany na tym komputerze!
    echo Pobierz i zainstaluj Node.js ze strony: https://nodejs.org
    echo Po instalacji kliknij ten plik ponownie.
    echo.
    pause
    exit /b
)

echo Node.js jest zainstalowany.
if not exist node_modules (
    echo Instalowanie bibliotek (npm install)...
    call npm install
)

echo Uruchamianie aplikacji i otwieranie w przegladarce Chrome / Edge...
start http://localhost:3000
npm run dev
